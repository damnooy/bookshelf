function submitBuku(e) {
    // get data dari formulir
    const judul = document.getElementById('judul').value;
    const penulis = document.getElementById('penulis').value;
    const tahun = document.getElementById('tahun').value;
    const checkBox = document.getElementById('checkBox').checked;

    // simpan data di localStorage
    const formData = {
        id: +new Date(),
        title: judul,
        author: penulis,
        year: parseInt(tahun),
        isComplete: checkBox,
      }

    //   ambil data dari localStorage dean key 'books', jika tidak ada set dengan array kosong
    const getBooks = localStorage.getItem('books') ? JSON.parse(localStorage.getItem('books')) : [];

    // simpan data, manfaatkan spread opertator untuk merge data
    localStorage.setItem('books', JSON.stringify ([...getBooks, formData]));

    alert('Buku Berhasil Ditambahkan!');
    // reset data dari formulir
    document.getElementById('judul').value = "";
    document.getElementById('penulis').value = "";
    document.getElementById('tahun').value = "";

    renderDataBuku();
}

// cari buku
function searchBook() {
    const searchInput = document.getElementById('searchInput').value;
    renderDataBuku(searchInput.toLowerCase());
}


// tampilkan data sesuai rak
function renderDataBuku(search = "") {
    //   ambil data dari localStorage dean key 'books', jika tidak ada set dengan array kosong
    const getBooks = localStorage.getItem('books') ? JSON.parse(localStorage.getItem('books')) : [];
    const getBooksFiltered = getBooks.filter((o) => o.title.toLowerCase().includes(search));

    const belumSelesai = document.getElementById('belumSelesai');
    const sudahSelesai = document.getElementById('sudahSelesai');

    belumSelesai.innerHTML = "";
    sudahSelesai.innerHTML = "";

    for (const book of getBooksFiltered) {
     if (book.isComplete) {
        sudahSelesai.innerHTML += `<div class="statusBaca mb-2">
        <h5>${book.title}</h3>
            <h6>By: ${book.author}</h6>
            <h6>Tahun: ${book.year}</h6>
            <button onclick="moveBook(${book.id}, false)" type="button" class="btn btn-success btnGreen my-1">Tandai belum selesai</button>
            <button onclick="deleteBook(${book.id})" type="button" class="btn btn-danger my-1">Hapus Buku</button>
    </div>`
     } else {
        belumSelesai.innerHTML += `<div class="statusBaca mb-2">
        <h5>${book.title}</h3>
            <h6>By: ${book.author}</h6>
            <h6>Tahun: ${book.year}</h6>
            <button onclick="moveBook(${book.id}, true)" type="button" class="btn btn-success btnGreen my-1">Tandai sudah selesai</button>
            <button onclick="deleteBook(${book.id})" type="button" class="btn btn-danger my-1">Hapus Buku</button>
    </div>`
     }
    }
}

// memindahkan data buku
function moveBook(id, isComplete) {
    console.log(id);
    //   ambil data dari localStorage dean key 'books', jika tidak ada set dengan array kosong
    const getBooks = localStorage.getItem('books') ? JSON.parse(localStorage.getItem('books')) : [];
console.log(getBooks);
    const findBook = getBooks.find((o) => o.id === id);
    console.log(findBook);
    const editBook = {...findBook, isComplete: isComplete};
    console.log(editBook);
    deleteBook(id);

    //   ambil data terbaru dari localStorage dean key 'books', jika tidak ada set dengan array kosong
    const getLatestBooks = localStorage.getItem('books') ? JSON.parse(localStorage.getItem('books')) : [];
    localStorage.setItem('books', JSON.stringify([...getLatestBooks, editBook]));
    renderDataBuku();
}

// menghapus data buku
function deleteBook(id) {
    //   ambil data dari localStorage dean key 'books', jika tidak ada set dengan array kosong
    const getBooks = localStorage.getItem('books') ? JSON.parse(localStorage.getItem('books')) : [];

    // ngambil data yang ngga dihapus
    const notDeleted = getBooks.filter((o) => o.id !== id);
    localStorage.setItem("books", JSON.stringify(notDeleted));

    renderDataBuku();
}

window.onload = function () {
    renderDataBuku();
}